param(
    [string]$Url = 'https://github.com/kower6766/aione/raw/refs/heads/main/test0.zip',
    [string]$OutFile = '.\test0.zip',
    [switch]$Force
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ScriptLogPath = 'C:\tmp\d.txt'

function Write-LogMessage {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Message
    )

    $logDirectory = Split-Path -Path $ScriptLogPath -Parent
    if (-not [string]::IsNullOrWhiteSpace($logDirectory) -and -not (Test-Path -LiteralPath $logDirectory)) {
        New-Item -ItemType Directory -Path $logDirectory -Force | Out-Null
    }

    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    Add-Content -Path $ScriptLogPath -Value "[$timestamp] $Message"
}

function Convert-GitHubUrlToRawUrl {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Url
    )

    $uri = [System.Uri]$Url

    if ($uri.Host -eq 'raw.githubusercontent.com') {
        return $Url
    }

    if ($uri.Host -ne 'github.com') {
        throw "Only github.com or raw.githubusercontent.com public file URLs are supported: $Url"
    }

    $segments = $uri.AbsolutePath.Trim('/') -split '/'
    if ($segments.Count -lt 5) {
        throw "Invalid GitHub file URL format: $Url"
    }

    $owner = $segments[0]
    $repo = $segments[1]
    $kind = $segments[2]
    $branch = $segments[3]
    $pathSegments = $segments[4..($segments.Count - 1)]

    if ($kind -ne 'blob' -and $kind -ne 'raw') {
        throw "Only GitHub file page URLs (.../blob/...) or raw URLs are supported: $Url"
    }

    $rawPath = ($pathSegments -join '/')
    return "https://raw.githubusercontent.com/$owner/$repo/$branch/$rawPath"
}

function Resolve-OutputPath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$RawUrl,
        [string]$OutFile
    )

    if ([string]::IsNullOrWhiteSpace($OutFile)) {
        $fileName = [System.IO.Path]::GetFileName(([System.Uri]$RawUrl).AbsolutePath)
        if ([string]::IsNullOrWhiteSpace($fileName)) {
            throw "Cannot infer output file name from URL. Please specify -OutFile explicitly."
        }

        return (Join-Path -Path (Get-Location) -ChildPath $fileName)
    }

    return [System.IO.Path]::GetFullPath($OutFile)
}

function Expand-DownloadedArchiveIfNeeded {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$DownloadedFilePath
    )

    if ([System.IO.Path]::GetExtension($DownloadedFilePath) -ine '.zip') {
        Write-LogMessage -Message "Skip archive extraction because file is not zip: $DownloadedFilePath"
        return $null
    }

    $destinationPath = (Get-Location).Path
    Write-LogMessage -Message "Extract zip archive to current directory: $destinationPath"
    Expand-Archive -LiteralPath $DownloadedFilePath -DestinationPath $destinationPath -Force
    return $destinationPath
}

function Invoke-DownloadedScriptIfNeeded {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$DownloadedFilePath
    )

    if ([System.IO.Path]::GetExtension($DownloadedFilePath) -ieq '.zip') {
        $extractedScriptPath = Join-Path -Path (Get-Location).Path -ChildPath 'rtest.ps1'
        if (Test-Path -LiteralPath $extractedScriptPath) {
            Write-LogMessage -Message "Execute extracted script: $extractedScriptPath"
            & $extractedScriptPath
            return $extractedScriptPath
        }

        Write-LogMessage -Message "No extracted rtest.ps1 found in current directory"
        return $null
    }

    if ([System.IO.Path]::GetFileName($DownloadedFilePath) -ine 'rtest.ps1') {
        Write-LogMessage -Message "Skip script execution because file name is not rtest.ps1: $DownloadedFilePath"
        return $null
    }

    Write-LogMessage -Message "Execute downloaded script: $DownloadedFilePath"
    & $DownloadedFilePath
    return $DownloadedFilePath
}

function Download-GitHubFile {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Url,
        [string]$OutFile,
        [switch]$Force
    )

    $rawUrl = Convert-GitHubUrlToRawUrl -Url $Url
    $targetPath = Resolve-OutputPath -RawUrl $rawUrl -OutFile $OutFile
    $targetDirectory = Split-Path -Path $targetPath -Parent

    Write-LogMessage -Message "Start download. Source URL: $Url"
    Write-LogMessage -Message "Resolved raw URL: $rawUrl"
    Write-LogMessage -Message "Resolved target path: $targetPath"

    if (-not [string]::IsNullOrWhiteSpace($targetDirectory) -and -not (Test-Path -LiteralPath $targetDirectory)) {
        Write-LogMessage -Message "Create target directory: $targetDirectory"
        New-Item -ItemType Directory -Path $targetDirectory -Force | Out-Null
    }

    if ((Test-Path -LiteralPath $targetPath) -and -not $Force.IsPresent) {
        Write-LogMessage -Message "Target file already exists and Force was not specified: $targetPath"
        throw "Target file already exists: $targetPath. Use -Force to overwrite it."
    }

    Write-LogMessage -Message "Download file to: $targetPath"
    Invoke-WebRequest -Uri $rawUrl -OutFile $targetPath
    Write-LogMessage -Message "Download completed: $targetPath"
    $extractedTo = Expand-DownloadedArchiveIfNeeded -DownloadedFilePath $targetPath
    $executedScript = Invoke-DownloadedScriptIfNeeded -DownloadedFilePath $targetPath

    if (-not [string]::IsNullOrWhiteSpace($extractedTo)) {
        Write-LogMessage -Message "Archive extracted to: $extractedTo"
    }

    if (-not [string]::IsNullOrWhiteSpace($executedScript)) {
        Write-LogMessage -Message "Script executed: $executedScript"
    }

    [PSCustomObject]@{
        RawUrl = $rawUrl
        SavedTo = $targetPath
        ExtractedTo = $extractedTo
        ExecutedScript = $executedScript
    }
}

if ($MyInvocation.InvocationName -ne '.') {
    Write-LogMessage -Message 'Script entry point started'
    $result = Download-GitHubFile -Url $Url -OutFile $OutFile -Force:$Force
    Write-Host "Download succeeded: $($result.RawUrl)"
    Write-Host "Saved to: $($result.SavedTo)"
    if (-not [string]::IsNullOrWhiteSpace($result.ExtractedTo)) {
        Write-Host "Extracted to current directory: $($result.ExtractedTo)"
    }
    if (-not [string]::IsNullOrWhiteSpace($result.ExecutedScript)) {
        Write-Host "Executed script: $($result.ExecutedScript)"
    }
    Write-LogMessage -Message 'Script entry point finished'
}
