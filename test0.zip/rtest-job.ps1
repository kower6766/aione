param(
    [string]$TaskMessage = '__FILL_TASK_MESSAGE__',
    [string]$LogPath = 'C:\my-job.log'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'

Write-Output "[$timestamp] my-job.ps1 started"

if ([string]::IsNullOrWhiteSpace($TaskMessage) -or $TaskMessage -eq '__FILL_TASK_MESSAGE__') {
    $TaskMessage = 'replace this text with your real job logic'
}

if (-not (Test-Path -LiteralPath (Split-Path -Path $LogPath -Parent))) {
    New-Item -ItemType Directory -Path (Split-Path -Path $LogPath -Parent) -Force | Out-Null
}

Add-Content -Path $LogPath -Value "[$timestamp] Message: $TaskMessage"

$urlTimestamp = Get-Date -Format 'yyyyMMddHHmmss'
$requestUrl = "https://www.baidu.com/asdakfjasldfj_$urlTimestamp"

try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $response = Invoke-WebRequest -Uri $requestUrl -UseBasicParsing
    Add-Content -Path $LogPath -Value "[$timestamp] RequestUrl: $requestUrl"
    Add-Content -Path $LogPath -Value "[$timestamp] StatusCode: $($response.StatusCode)"
}
catch {
    Add-Content -Path $LogPath -Value "[$timestamp] RequestUrl: $requestUrl"
    Add-Content -Path $LogPath -Value "[$timestamp] Request failed: $($_.Exception.Message)"
}

# TODO: Put your real job here after the web request example.
# Example:
# Start-Process -FilePath 'notepad.exe'

Write-Output "[$timestamp] my-job.ps1 finished"
