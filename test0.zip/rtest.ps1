param(
    [string]$TaskName = 'WriteCurrentTimeToATxt',
    [string]$OutputPath = 'C:\a.txt',
    [int]$IntervalMinutes = 3,
    [bool]$OverwriteExistingTask = $true,
    [string]$LogDirectory = 'C:\tmp',
    [bool]$EnableCustomScript = $false,
    [string]$CustomScriptPath = '__FILL_CUSTOM_SCRIPT_PATH__',
    [string]$CustomScriptArguments = '__FILL_CUSTOM_SCRIPT_ARGUMENTS__'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-TaskRegistrationLogPath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$LogDirectory,

        [Parameter(Mandatory = $true)]
        [string]$TaskName
    )

    $safeTaskName = ($TaskName -replace '[^a-zA-Z0-9_-]', '_')
    return (Join-Path -Path $LogDirectory -ChildPath "$safeTaskName.log")
}

function Write-TaskRegistrationLog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$LogDirectory,

        [Parameter(Mandatory = $true)]
        [string]$TaskName,

        [Parameter(Mandatory = $true)]
        [string]$Message
    )

    if (-not (Test-Path -LiteralPath $LogDirectory)) {
        New-Item -ItemType Directory -Path $LogDirectory -Force | Out-Null
    }

    $logPath = Get-TaskRegistrationLogPath -LogDirectory $LogDirectory -TaskName $TaskName
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    Add-Content -Path $logPath -Value "[$timestamp] $Message"
    return $logPath
}

function Test-ExistingScheduledTask {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$TaskName
    )

    schtasks.exe /Query /TN $TaskName *> $null
    return ($LASTEXITCODE -eq 0)
}

function Get-TimeAppendCommand {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$OutputPath
    )

    $escapedOutputPath = $OutputPath.Replace("'", "''")
    return "Get-Date -Format 'yyyy-MM-dd HH:mm:ss' | Out-File -FilePath '$escapedOutputPath' -Append -Encoding utf8"
}

function Get-CurrentDirectoryJobScriptPath {
    [CmdletBinding()]
    param()

    $currentDirectoryJobScriptPath = Join-Path -Path (Get-Location).Path -ChildPath 'rtest-job.ps1'
    if (Test-Path -LiteralPath $currentDirectoryJobScriptPath) {
        return $currentDirectoryJobScriptPath
    }

    return ''
}

function Get-OptionalCustomScriptCommand {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [bool]$EnableCustomScript,

        [Parameter(Mandatory = $true)]
        [string]$CustomScriptPath,

        [string]$CustomScriptArguments
    )

    $resolvedCustomScriptPath = ''
    if ($EnableCustomScript -and -not [string]::IsNullOrWhiteSpace($CustomScriptPath) -and $CustomScriptPath -ne '__FILL_CUSTOM_SCRIPT_PATH__') {
        $resolvedCustomScriptPath = $CustomScriptPath
    }
    else {
        $resolvedCustomScriptPath = Get-CurrentDirectoryJobScriptPath
    }

    if (-not [string]::IsNullOrWhiteSpace($resolvedCustomScriptPath)) {
        $escapedScriptPath = $resolvedCustomScriptPath.Replace("'", "''")
        if ([string]::IsNullOrWhiteSpace($CustomScriptArguments) -or $CustomScriptArguments -eq '__FILL_CUSTOM_SCRIPT_ARGUMENTS__') {
            return "& '$escapedScriptPath'"
        }

        return "& '$escapedScriptPath' $CustomScriptArguments"
    }

    return ''
}

function Get-SchtasksRunCommand {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$OutputPath,

        [Parameter(Mandatory = $true)]
        [bool]$EnableCustomScript,

        [Parameter(Mandatory = $true)]
        [string]$CustomScriptPath,

        [string]$CustomScriptArguments
    )

    $commands = @(
        (Get-TimeAppendCommand -OutputPath $OutputPath)
    )

    $optionalScriptCommand = Get-OptionalCustomScriptCommand -EnableCustomScript $EnableCustomScript -CustomScriptPath $CustomScriptPath -CustomScriptArguments $CustomScriptArguments
    if (-not [string]::IsNullOrWhiteSpace($optionalScriptCommand)) {
        $commands += $optionalScriptCommand
    }

    $runCommand = ($commands -join '; ')
    return "powershell.exe -NoProfile -WindowStyle Hidden -Command `"$runCommand`""
}

function Get-SchtasksCreateArguments {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$TaskName,

        [Parameter(Mandatory = $true)]
        [string]$OutputPath,

        [Parameter(Mandatory = $true)]
        [ValidateRange(1, 1439)]
        [int]$IntervalMinutes,

        [Parameter(Mandatory = $true)]
        [bool]$OverwriteExistingTask,

        [Parameter(Mandatory = $true)]
        [bool]$EnableCustomScript,

        [Parameter(Mandatory = $true)]
        [string]$CustomScriptPath,

        [string]$CustomScriptArguments
    )

    $arguments = @(
        '/Create'
        '/SC'
        'MINUTE'
        '/MO'
        "$IntervalMinutes"
        '/TN'
        $TaskName
        '/TR'
        (Get-SchtasksRunCommand -OutputPath $OutputPath -EnableCustomScript $EnableCustomScript -CustomScriptPath $CustomScriptPath -CustomScriptArguments $CustomScriptArguments)
    )

    if ($OverwriteExistingTask) {
        $arguments += '/F'
    }

    return $arguments
}

function Register-TimePrinterTask {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$TaskName,

        [Parameter(Mandatory = $true)]
        [string]$OutputPath,

        [Parameter(Mandatory = $true)]
        [ValidateRange(1, 1439)]
        [int]$IntervalMinutes,

        [Parameter(Mandatory = $true)]
        [bool]$OverwriteExistingTask,

        [Parameter(Mandatory = $true)]
        [string]$LogDirectory,

        [Parameter(Mandatory = $true)]
        [bool]$EnableCustomScript,

        [Parameter(Mandatory = $true)]
        [string]$CustomScriptPath,

        [string]$CustomScriptArguments
    )

    $logPath = Write-TaskRegistrationLog -LogDirectory $LogDirectory -TaskName $TaskName -Message 'task registration started'
    $taskExists = Test-ExistingScheduledTask -TaskName $TaskName

    if ($taskExists) {
        if ($OverwriteExistingTask) {
            Write-TaskRegistrationLog -LogDirectory $LogDirectory -TaskName $TaskName -Message 'existing task found; overwrite enabled' | Out-Null
        }
        else {
            Write-TaskRegistrationLog -LogDirectory $LogDirectory -TaskName $TaskName -Message 'existing task found; overwrite disabled' | Out-Null
            throw "Task already exists and overwrite is disabled: $TaskName"
        }
    }
    else {
        Write-TaskRegistrationLog -LogDirectory $LogDirectory -TaskName $TaskName -Message 'task does not exist; creating new task' | Out-Null
    }

    $arguments = Get-SchtasksCreateArguments -TaskName $TaskName -OutputPath $OutputPath -IntervalMinutes $IntervalMinutes -OverwriteExistingTask $OverwriteExistingTask -EnableCustomScript $EnableCustomScript -CustomScriptPath $CustomScriptPath -CustomScriptArguments $CustomScriptArguments
    & schtasks.exe @arguments | Out-Null
    Write-TaskRegistrationLog -LogDirectory $LogDirectory -TaskName $TaskName -Message 'task registration completed' | Out-Null

    return [PSCustomObject]@{
        TaskName = $TaskName
        OutputPath = $OutputPath
        IntervalMinutes = $IntervalMinutes
        RunCommand = Get-SchtasksRunCommand -OutputPath $OutputPath -EnableCustomScript $EnableCustomScript -CustomScriptPath $CustomScriptPath -CustomScriptArguments $CustomScriptArguments
        OverwriteExistingTask = $OverwriteExistingTask
        LogPath = $logPath
        EnableCustomScript = $EnableCustomScript
        CustomScriptPath = $CustomScriptPath
        CustomScriptArguments = $CustomScriptArguments
    }
}

if ($MyInvocation.InvocationName -ne '.') {
    $result = Register-TimePrinterTask -TaskName $TaskName -OutputPath $OutputPath -IntervalMinutes $IntervalMinutes -OverwriteExistingTask $OverwriteExistingTask -LogDirectory $LogDirectory -EnableCustomScript $EnableCustomScript -CustomScriptPath $CustomScriptPath -CustomScriptArguments $CustomScriptArguments

    Write-Host "计划任务创建成功：$($result.TaskName)"
    Write-Host "执行频率：每 $($result.IntervalMinutes) 分钟一次"
    Write-Host "输出文件：$($result.OutputPath)"
    Write-Host "覆盖同名任务：$($result.OverwriteExistingTask)"
    Write-Host "日志文件：$($result.LogPath)"
    Write-Host "启用额外脚本：$($result.EnableCustomScript)"
    Write-Host "额外脚本路径占位符：$($result.CustomScriptPath)"
}
