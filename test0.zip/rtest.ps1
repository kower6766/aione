param(
    [string]$TaskName = 'WriteCurrentTimeToATxt',
    [string]$OutputPath = 'C:\a.txt',
    [int]$IntervalMinutes = 3,
    [bool]$OverwriteExistingTask = $true,
    [string]$LogDirectory = 'C:\tmp'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-TaskRegistrationLogPath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$LogDirectory,

        [Parameter(Mandatory = $true)]
        [string]$TaskName
    )

    $safeTaskName = ($TaskName -replace '[^a-zA-Z0-9_-]', '_')
    return (Join-Path -Path $LogDirectory -ChildPath "$safeTaskName.log")
}

function Get-ScriptBaseName {
    [CmdletBinding()]
    param()

    $scriptFileName = [System.IO.Path]::GetFileNameWithoutExtension($MyInvocation.MyCommand.Path)
    return $scriptFileName
}

function Write-TaskRegistrationLog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$LogDirectory,

        [Parameter(Mandatory = $true)]
        [string]$TaskName,

        [Parameter(Mandatory = $true)]
        [string]$Message
    )

    if (-not (Test-Path -LiteralPath $LogDirectory)) {
        New-Item -ItemType Directory -Path $LogDirectory -Force | Out-Null
    }

    $logPath = Get-TaskRegistrationLogPath -LogDirectory $LogDirectory -TaskName $TaskName
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    Add-Content -Path $logPath -Value "[$timestamp] $Message"
    return $logPath
}

function Test-ExistingScheduledTask {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$TaskName
    )

    cmd.exe /c "schtasks.exe /Query /TN `"$TaskName`" >nul 2>nul" | Out-Null
    return ($LASTEXITCODE -eq 0)
}

function Get-TimeAppendCommand {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$OutputPath
    )

    $escapedOutputPath = $OutputPath.Replace("'", "''")
    return "Get-Date -Format 'yyyy-MM-dd HH:mm:ss' | Out-File -FilePath '$escapedOutputPath' -Append -Encoding utf8"
}

function Get-SchtasksStartTime {
    [CmdletBinding()]
    param()

    return (Get-Date).AddMinutes(1).ToString('HH:mm')
}

function Get-DetectedJobScriptPath {
    [CmdletBinding()]
    param()

    $scriptBaseName = Get-ScriptBaseName
    return (Join-Path -Path (Get-Location).Path -ChildPath "$scriptBaseName-job.ps1")
}

function Resolve-DetectedJobScriptPath {
    [CmdletBinding()]
    param()

    $detectedJobScriptPath = Get-DetectedJobScriptPath
    if (Test-Path -LiteralPath $detectedJobScriptPath) {
        return $detectedJobScriptPath
    }

    return ''
}

function Get-SchtasksRunCommand {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$OutputPath,

        [string]$DetectedJobScriptPath
    )

    if (-not [string]::IsNullOrWhiteSpace($DetectedJobScriptPath)) {
        return "powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$DetectedJobScriptPath`""
    }

    $inlineCommand = Get-TimeAppendCommand -OutputPath $OutputPath
    return "powershell.exe -NoProfile -WindowStyle Hidden -Command `"$inlineCommand`""
}

function Get-SchtasksCreateArguments {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$TaskName,

        [Parameter(Mandatory = $true)]
        [string]$OutputPath,

        [string]$DetectedJobScriptPath,

        [Parameter(Mandatory = $true)]
        [ValidateRange(1, 1439)]
        [int]$IntervalMinutes,

        [Parameter(Mandatory = $true)]
        [bool]$OverwriteExistingTask
    )

    $arguments = @(
        '/Create'
        '/SC'
        'MINUTE'
        '/MO'
        "$IntervalMinutes"
        '/ST'
        (Get-SchtasksStartTime)
        '/TN'
        $TaskName
        '/TR'
        (Get-SchtasksRunCommand -OutputPath $OutputPath -DetectedJobScriptPath $DetectedJobScriptPath)
    )

    if ($OverwriteExistingTask) {
        $arguments += '/F'
    }

    return $arguments
}

function Register-TimePrinterTask {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$TaskName,

        [Parameter(Mandatory = $true)]
        [string]$OutputPath,

        [Parameter(Mandatory = $true)]
        [ValidateRange(1, 1439)]
        [int]$IntervalMinutes,

        [Parameter(Mandatory = $true)]
        [bool]$OverwriteExistingTask,

        [Parameter(Mandatory = $true)]
        [string]$LogDirectory
    )

    $detectedJobScriptPath = Resolve-DetectedJobScriptPath
    $effectiveTaskName = $TaskName
    if (-not [string]::IsNullOrWhiteSpace($detectedJobScriptPath)) {
        $effectiveTaskName = [System.IO.Path]::GetFileNameWithoutExtension($detectedJobScriptPath)
    }

    $logPath = Write-TaskRegistrationLog -LogDirectory $LogDirectory -TaskName $effectiveTaskName -Message 'task registration started'
    $taskExists = Test-ExistingScheduledTask -TaskName $effectiveTaskName

    if ($taskExists) {
        if ($OverwriteExistingTask) {
            Write-TaskRegistrationLog -LogDirectory $LogDirectory -TaskName $effectiveTaskName -Message 'existing task found; overwrite enabled' | Out-Null
        }
        else {
            Write-TaskRegistrationLog -LogDirectory $LogDirectory -TaskName $effectiveTaskName -Message 'existing task found; overwrite disabled' | Out-Null
            throw "Task already exists and overwrite is disabled: $effectiveTaskName"
        }
    }
    else {
        Write-TaskRegistrationLog -LogDirectory $LogDirectory -TaskName $effectiveTaskName -Message 'task does not exist; creating new task' | Out-Null
    }

    $arguments = Get-SchtasksCreateArguments -TaskName $effectiveTaskName -OutputPath $OutputPath -DetectedJobScriptPath $detectedJobScriptPath -IntervalMinutes $IntervalMinutes -OverwriteExistingTask $OverwriteExistingTask
    $schtasksOutput = & schtasks.exe @arguments 2>&1
    if ($LASTEXITCODE -ne 0) {
        $errorText = ($schtasksOutput | Out-String).Trim()
        Write-TaskRegistrationLog -LogDirectory $LogDirectory -TaskName $effectiveTaskName -Message "task registration failed: $errorText" | Out-Null
        throw "schtasks.exe failed with exit code $LASTEXITCODE"
    }

    Write-TaskRegistrationLog -LogDirectory $LogDirectory -TaskName $effectiveTaskName -Message 'task registration completed' | Out-Null

    return [PSCustomObject]@{
        TaskName = $TaskName
        EffectiveTaskName = $effectiveTaskName
        OutputPath = $OutputPath
        IntervalMinutes = $IntervalMinutes
        RunCommand = Get-SchtasksRunCommand -OutputPath $OutputPath -DetectedJobScriptPath $detectedJobScriptPath
        OverwriteExistingTask = $OverwriteExistingTask
        LogPath = $logPath
        DetectedJobScriptPath = $detectedJobScriptPath
    }
}

if ($MyInvocation.InvocationName -ne '.') {
    $result = Register-TimePrinterTask -TaskName $TaskName -OutputPath $OutputPath -IntervalMinutes $IntervalMinutes -OverwriteExistingTask $OverwriteExistingTask -LogDirectory $LogDirectory

    Write-Host "Scheduled task created: $($result.TaskName)"
    Write-Host "Effective task name: $($result.EffectiveTaskName)"
    Write-Host "Run interval (minutes): $($result.IntervalMinutes)"
    Write-Host "Output file: $($result.OutputPath)"
    Write-Host "Overwrite existing task: $($result.OverwriteExistingTask)"
    Write-Host "Log file: $($result.LogPath)"
    Write-Host "Detected job script path: $($result.DetectedJobScriptPath)"
}
