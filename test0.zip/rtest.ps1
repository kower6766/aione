param(
    [string]$TaskName = 'WriteCurrentTimeToATxt',
    [int]$IntervalMinutes = 3,
    [bool]$OverwriteExistingTask = $true,
    [string]$LogDirectory = 'C:\tmp'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:CurrentScriptPath = $PSCommandPath
$script:TaskRegistrationLogPath = ''

function Get-TaskRegistrationLogPath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$LogDirectory,

        [Parameter(Mandatory = $true)]
        [string]$TaskName
    )

    if ([string]::IsNullOrWhiteSpace($script:TaskRegistrationLogPath)) {
        $timestamp = Get-Date -Format 'yyyy-MM-dd_HH-mm-ss'
        $logFileName = "$timestamp.txt"
        $script:TaskRegistrationLogPath = Join-Path -Path $LogDirectory -ChildPath $logFileName
    }

    return $script:TaskRegistrationLogPath
}

function Write-TaskRegistrationLog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$LogDirectory,

        [Parameter(Mandatory = $true)]
        [string]$TaskName,

        [Parameter(Mandatory = $true)]
        [string]$Message
    )

    if (-not (Test-Path -LiteralPath $LogDirectory)) {
        New-Item -ItemType Directory -Path $LogDirectory -Force | Out-Null
    }

    $logPath = Get-TaskRegistrationLogPath -LogDirectory $LogDirectory -TaskName $TaskName
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    Add-Content -Path $logPath -Value "[$timestamp] $Message"
    return $logPath
}

function Test-ExistingScheduledTask {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$TaskName
    )

    cmd.exe /c "schtasks.exe /Query /TN `"$TaskName`" >nul 2>nul" | Out-Null
    return ($LASTEXITCODE -eq 0)
}

function Get-SchtasksStartTime {
    [CmdletBinding()]
    param()

    return (Get-Date).AddMinutes(1).ToString('HH:mm')
}

function Get-DetectedJobScriptPath {
    [CmdletBinding()]
    param()

    # Matches examples such as rtest-jobv2.ps1 and rtest-job-asdfasfd.ps1.
    $jobScripts = @(Get-ChildItem -Path (Get-Location).Path -Filter 'rtest-job*.ps1' -File | Sort-Object -Property Name)
    if ($jobScripts.Count -gt 0) {
        return $jobScripts[0].FullName
    }

    return ''
}

function Resolve-DetectedJobScriptPath {
    [CmdletBinding()]
    param()

    $detectedJobScriptPath = Get-DetectedJobScriptPath
    if (-not [string]::IsNullOrWhiteSpace($detectedJobScriptPath) -and (Test-Path -LiteralPath $detectedJobScriptPath)) {
        return $detectedJobScriptPath
    }

    return ''
}

function Get-SchtasksRunCommand {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$DetectedJobScriptPath
    )

    return "powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$DetectedJobScriptPath`""
}

function Get-SchtasksCreateArguments {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$TaskName,

        [Parameter(Mandatory = $true)]
        [string]$DetectedJobScriptPath,

        [Parameter(Mandatory = $true)]
        [ValidateRange(1, 1439)]
        [int]$IntervalMinutes,

        [Parameter(Mandatory = $true)]
        [bool]$OverwriteExistingTask
    )

    $arguments = @(
        '/Create'
        '/SC'
        'MINUTE'
        '/MO'
        "$IntervalMinutes"
        '/ST'
        (Get-SchtasksStartTime)
        '/TN'
        $TaskName
        '/TR'
        (Get-SchtasksRunCommand -DetectedJobScriptPath $DetectedJobScriptPath)
    )

    if ($OverwriteExistingTask) {
        $arguments += '/F'
    }

    return $arguments
}

function Register-TimePrinterTask {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$TaskName,

        [Parameter(Mandatory = $true)]
        [ValidateRange(1, 1439)]
        [int]$IntervalMinutes,

        [Parameter(Mandatory = $true)]
        [bool]$OverwriteExistingTask,

        [Parameter(Mandatory = $true)]
        [string]$LogDirectory
    )

    $detectedJobScriptPath = Resolve-DetectedJobScriptPath
    if ([string]::IsNullOrWhiteSpace($detectedJobScriptPath)) {
        $failureTaskName = 'rtest-job-not-found'
        Write-TaskRegistrationLog -LogDirectory $LogDirectory -TaskName $failureTaskName -Message 'task registration failed: no rtest-job*.ps1 found in current directory' | Out-Null
        throw "No rtest-job*.ps1 script found in current directory"
    }

    $effectiveTaskName = $TaskName
    if (-not [string]::IsNullOrWhiteSpace($detectedJobScriptPath)) {
        $effectiveTaskName = [System.IO.Path]::GetFileNameWithoutExtension($detectedJobScriptPath)
    }

    $logPath = Write-TaskRegistrationLog -LogDirectory $LogDirectory -TaskName $effectiveTaskName -Message 'task registration started'
    $taskExists = Test-ExistingScheduledTask -TaskName $effectiveTaskName

    if ($taskExists) {
        if ($OverwriteExistingTask) {
            Write-TaskRegistrationLog -LogDirectory $LogDirectory -TaskName $effectiveTaskName -Message 'existing task found; overwrite enabled' | Out-Null
        }
        else {
            Write-TaskRegistrationLog -LogDirectory $LogDirectory -TaskName $effectiveTaskName -Message 'existing task found; overwrite disabled' | Out-Null
            throw "Task already exists and overwrite is disabled: $effectiveTaskName"
        }
    }
    else {
        Write-TaskRegistrationLog -LogDirectory $LogDirectory -TaskName $effectiveTaskName -Message 'task does not exist; creating new task' | Out-Null
    }

    $arguments = Get-SchtasksCreateArguments -TaskName $effectiveTaskName -DetectedJobScriptPath $detectedJobScriptPath -IntervalMinutes $IntervalMinutes -OverwriteExistingTask $OverwriteExistingTask
    $schtasksOutput = & schtasks.exe @arguments 2>&1
    if ($LASTEXITCODE -ne 0) {
        $errorText = ($schtasksOutput | Out-String).Trim()
        Write-TaskRegistrationLog -LogDirectory $LogDirectory -TaskName $effectiveTaskName -Message "task registration failed: $errorText" | Out-Null
        throw "schtasks.exe failed with exit code $LASTEXITCODE"
    }

    Write-TaskRegistrationLog -LogDirectory $LogDirectory -TaskName $effectiveTaskName -Message 'task registration completed' | Out-Null

    return [PSCustomObject]@{
        TaskName = $effectiveTaskName
        RequestedTaskName = $TaskName
        EffectiveTaskName = $effectiveTaskName
        IntervalMinutes = $IntervalMinutes
        RunCommand = Get-SchtasksRunCommand -DetectedJobScriptPath $detectedJobScriptPath
        OverwriteExistingTask = $OverwriteExistingTask
        LogPath = $logPath
        DetectedJobScriptPath = $detectedJobScriptPath
    }
}

if ($MyInvocation.InvocationName -ne '.') {
    $result = Register-TimePrinterTask -TaskName $TaskName -IntervalMinutes $IntervalMinutes -OverwriteExistingTask $OverwriteExistingTask -LogDirectory $LogDirectory

    Write-Host "Scheduled task created: $($result.TaskName)"
    Write-Host "Requested task name: $($result.RequestedTaskName)"
    Write-Host "Effective task name: $($result.EffectiveTaskName)"
    Write-Host "Run interval (minutes): $($result.IntervalMinutes)"
    Write-Host "Overwrite existing task: $($result.OverwriteExistingTask)"
    Write-Host "Log file: $($result.LogPath)"
    Write-Host "Detected job script path: $($result.DetectedJobScriptPath)"
}
